import unittest
import io
import json
import sys
import tempfile
from pathlib import Path
from contextlib import redirect_stdout, redirect_stderr

from app.main import TaskManager, run_demo


class TestTaskManager(unittest.TestCase):
    def test_add_task_creates_file_and_content(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            f_out = io.StringIO()
            with redirect_stdout(f_out):
                mgr.add('Test task')
            self.assertIn('Added task [1]: Test task', f_out.getvalue())
            # Verify file exists and content is correct
            self.assertTrue(storage.exists())
            data = json.loads(storage.read_text(encoding='utf-8'))
            self.assertEqual(len(data), 1)
            task = data[0]
            self.assertEqual(task['id'], 1)
            self.assertEqual(task['description'], 'Test task')
            self.assertFalse(task['completed'])

    def test_add_empty_description_exits(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            f_err = io.StringIO()
            with self.assertRaises(SystemExit) as cm, redirect_stderr(f_err):
                mgr.add('   ')
            self.assertEqual(cm.exception.code, 1)
            self.assertIn('Error: task description cannot be empty.', f_err.getvalue())

    def test_list_no_tasks_output(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            f_out = io.StringIO()
            with redirect_stdout(f_out):
                mgr.list()
            self.assertEqual(f_out.getvalue().strip(), 'No tasks found.')

    def test_complete_task_marks_completed_and_persists(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            mgr.add('First')
            mgr.add('Second')
            f_out = io.StringIO()
            with redirect_stdout(f_out):
                mgr.complete(1)
            self.assertIn('Marked task [1] as completed.', f_out.getvalue())
            # Load a fresh manager to verify persistence
            fresh = TaskManager(storage_path=storage)
            self.assertTrue(any(t['id'] == 1 and t['completed'] for t in fresh.tasks))
            self.assertTrue(any(t['id'] == 2 and not t['completed'] for t in fresh.tasks))

    def test_complete_invalid_id_exits(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            mgr.add('Only task')
            f_err = io.StringIO()
            with self.assertRaises(SystemExit) as cm, redirect_stderr(f_err):
                mgr.complete(99)
            self.assertEqual(cm.exception.code, 1)
            self.assertIn('Error: no task with id 99.', f_err.getvalue())

    def test_delete_task_removes_and_persists(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            mgr.add('Task A')
            mgr.add('Task B')
            f_out = io.StringIO()
            with redirect_stdout(f_out):
                mgr.delete(2)
            self.assertIn('Deleted task [2]: Task B', f_out.getvalue())
            # Verify file now contains only task 1
            data = json.loads(storage.read_text(encoding='utf-8'))
            self.assertEqual(len(data), 1)
            self.assertEqual(data[0]['id'], 1)
            self.assertEqual(data[0]['description'], 'Task A')

    def test_delete_invalid_id_exits(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            mgr = TaskManager(storage_path=storage)
            mgr.add('Solo')
            f_err = io.StringIO()
            with self.assertRaises(SystemExit) as cm, redirect_stderr(f_err):
                mgr.delete(5)
            self.assertEqual(cm.exception.code, 1)
            self.assertIn('Error: no task with id 5.', f_err.getvalue())

    def test_persistence_across_instances(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            # First instance adds a task
            mgr1 = TaskManager(storage_path=storage)
            mgr1.add('Persisted task')
            # Second instance loads the same file
            mgr2 = TaskManager(storage_path=storage)
            self.assertEqual(len(mgr2.tasks), 1)
            self.assertEqual(mgr2.tasks[0]['description'], 'Persisted task')

    def test_malformed_json_handling(self):
        with tempfile.TemporaryDirectory() as td:
            storage = Path(td) / 'tasks.json'
            storage.write_text('not a json', encoding='utf-8')
            mgr = TaskManager(storage_path=storage)
            # Should start with empty list despite malformed file
            self.assertEqual(mgr.tasks, [])
            # Adding a task should overwrite the file with proper JSON
            mgr.add('Recovered')
            data = json.loads(storage.read_text(encoding='utf-8'))
            self.assertEqual(len(data), 1)
            self.assertEqual(data[0]['description'], 'Recovered')

    def test_run_demo_output(self):
        f_out = io.StringIO()
        with redirect_stdout(f_out):
            run_demo()
        output = f_out.getvalue()
        # Verify key sections of the deterministic demo
        self.assertIn('--- Task Manager Demo ---', output)
        self.assertIn('Added task [1]: Buy milk', output)
        self.assertIn('Added task [2]: Read book', output)
        self.assertIn('Marked task [1] as completed.', output)
        self.assertIn('Deleted task [2]: Read book', output)
        self.assertIn('--- Demo finished ---', output)

if __name__ == '__main__':
    unittest.main()