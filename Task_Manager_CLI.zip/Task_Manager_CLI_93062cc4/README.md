# Task Manager CLI
Python standard-library task manager with JSON persistence, CRUD operations, and unit tests.
## Usage
Run: python -m app.main
Tests: python -m unittest discover -s tests -v
