import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

DEFAULT_STORAGE = Path(__file__).with_name('tasks.json')

class TaskManager:
    def __init__(self, storage_path: Path = DEFAULT_STORAGE):
        self.storage_path = storage_path
        self.tasks = []
        self._load()

    def _load(self):
        if not self.storage_path.exists():
            self.tasks = []
            return
        try:
            with self.storage_path.open('r', encoding='utf-8') as f:
                data = json.load(f)
            # Validate structure minimally
            if isinstance(data, list):
                self.tasks = [t for t in data if self._valid_task_dict(t)]
            else:
                self.tasks = []
        except (json.JSONDecodeError, OSError):
            # Malformed file – start fresh
            self.tasks = []

    def _save(self):
        try:
            with self.storage_path.open('w', encoding='utf-8') as f:
                json.dump(self.tasks, f, indent=2, ensure_ascii=False)
        except OSError as e:
            print(f"Error writing storage file: {e}", file=sys.stderr)
            sys.exit(1)

    @staticmethod
    def _valid_task_dict(d):
        return (
            isinstance(d, dict)
            and isinstance(d.get('id'), int)
            and isinstance(d.get('description'), str)
            and isinstance(d.get('completed'), bool)
        )

    def _next_id(self):
        if not self.tasks:
            return 1
        return max(t['id'] for t in self.tasks) + 1

    def add(self, description: str):
        description = description.strip()
        if not description:
            print('Error: task description cannot be empty.', file=sys.stderr)
            sys.exit(1)
        task = {
            'id': self._next_id(),
            'description': description,
            'completed': False,
        }
        self.tasks.append(task)
        self._save()
        print(f"Added task [{task['id']}]: {task['description']}")

    def list(self):
        if not self.tasks:
            print('No tasks found.')
            return
        for t in self.tasks:
            status = 'x' if t['completed'] else ' '
            print(f"[{t['id']}] [{status}] {t['description']}")

    def _find_index(self, task_id: int):
        for idx, t in enumerate(self.tasks):
            if t['id'] == task_id:
                return idx
        return None

    def complete(self, task_id: int):
        idx = self._find_index(task_id)
        if idx is None:
            print(f"Error: no task with id {task_id}.", file=sys.stderr)
            sys.exit(1)
        if self.tasks[idx]['completed']:
            print(f"Task [{task_id}] is already completed.")
        else:
            self.tasks[idx]['completed'] = True
            self._save()
            print(f"Marked task [{task_id}] as completed.")

    def delete(self, task_id: int):
        idx = self._find_index(task_id)
        if idx is None:
            print(f"Error: no task with id {task_id}.", file=sys.stderr)
            sys.exit(1)
        removed = self.tasks.pop(idx)
        self._save()
        print(f"Deleted task [{removed['id']}]: {removed['description']}")


def build_parser():
    parser = argparse.ArgumentParser(prog='taskmgr', description='Simple task manager CLI')
    subparsers = parser.add_subparsers(dest='command')

    # add
    parser_add = subparsers.add_parser('add', help='Add a new task')
    parser_add.add_argument('description', nargs='+', help='Description of the task')

    # list
    subparsers.add_parser('list', help='List all tasks')

    # complete
    parser_complete = subparsers.add_parser('complete', help='Mark a task as completed')
    parser_complete.add_argument('id', type=int, help='ID of the task to complete')

    # delete
    parser_delete = subparsers.add_parser('delete', help='Delete a task')
    parser_delete.add_argument('id', type=int, help='ID of the task to delete')

    return parser


def run_demo():
    print('--- Task Manager Demo ---')
    # Use a temporary file so the demo does not interfere with real data
    with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as tmp:
        demo_path = Path(tmp.name)
    try:
        mgr = TaskManager(storage_path=demo_path)
        # Add two tasks
        mgr.add('Buy milk')
        mgr.add('Read book')
        print('\nCurrent tasks:')
        mgr.list()
        # Complete first task
        mgr.complete(1)
        # Delete second task
        mgr.delete(2)
        print('\nFinal tasks:')
        mgr.list()
    finally:
        # Clean up demo file
        try:
            demo_path.unlink()
        except OSError:
            pass
    print('--- Demo finished ---')


def main():
    # If no arguments are supplied, run the deterministic demo
    if len(sys.argv) == 1:
        run_demo()
        sys.exit(0)

    parser = build_parser()
    args = parser.parse_args()
    manager = TaskManager()

    if args.command == 'add':
        description = ' '.join(args.description)
        manager.add(description)
    elif args.command == 'list':
        manager.list()
    elif args.command == 'complete':
        manager.complete(args.id)
    elif args.command == 'delete':
        manager.delete(args.id)
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == '__main__':
    main()
